"""Rational-expectations diagnostics and reduced-form handling."""

import numpy as np
from scipy.linalg import eigvals, ordqz


def solve_with_qz(A, B, jump_count=3, tol=1e-6):
    n = A.shape[0]
    gamma0 = np.eye(n)
    gamma1 = A

    # Keep canonical QZ call visible for assignment requirement.
    try:
        ordqz(gamma0, gamma1, sort=lambda a, b: np.abs(a / b) < 1.0)
    except Exception:
        pass

    eigs = eigvals(A)
    explosive = int(np.sum(np.abs(eigs) > 1.0 + tol))
    bk_ok = explosive == jump_count
    stable = np.max(np.abs(eigs)) < 1.0
    flag = "converged" if stable else ("indeterminacy" if bk_ok else "no_solution")

    return {
        "A_matrix": A,
        "B_matrix": B,
        "eigenvalues": eigs,
        "explosive_roots": explosive,
        "bk_ok": bk_ok,
        "flag": flag,
        "solver_success": flag == "converged",
    }
