"""Build a compact linear state-space representation."""

import numpy as np


def build_state_space(params):
    # States: y, c, i, b, pi, l, rn
    n = 7
    m = 6  # tfp, gov, mon, tax_l, tax_k, risk

    h = params["habit"]
    theta_p = params["theta_p"]
    theta_w = params["theta_w"]
    psi = params["psi"]
    phi_b = params["phi_b"]
    phi_pi = params["phi_pi"]
    phi_y = params["phi_y"]
    lam = params["lambda_rot"]

    A = np.zeros((n, n))
    B = np.zeros((n, m))

    # Output persistence and channels.
    A[0, 0] = 0.55 + 0.15 * h
    A[0, 1] = 0.20
    A[0, 2] = 0.15
    A[0, 3] = -0.08

    # Consumption smoother with habit.
    A[1, 1] = 0.45 + 0.45 * h
    A[1, 0] = 0.20
    A[1, 4] = -0.05

    # Investment more volatile and sensitive to policy rates.
    A[2, 2] = 0.35 + 0.10 * psi
    A[2, 0] = 0.35
    A[2, 6] = -0.15

    # Debt law of motion with feedback.
    A[3, 3] = 0.96 - 0.50 * phi_b
    A[3, 0] = -0.05

    # NK-style inflation block.
    kappa_p = (1.0 - theta_p) * (1.0 - params["beta"] * theta_p) / max(theta_p, 1e-6)
    A[4, 4] = 0.60
    A[4, 0] = 0.15 * kappa_p

    # Hours.
    A[5, 5] = 0.40 + 0.30 * (1.0 - theta_w)
    A[5, 0] = 0.25

    # Real rate proxy (Taylor + Fisher reduced form).
    A[6, 6] = params["rho_i"]
    A[6, 4] = (1.0 - params["rho_i"]) * phi_pi
    A[6, 0] = (1.0 - params["rho_i"]) * phi_y

    # Shock loadings.
    scale = params["sigma_x"]
    B[0, 0] = 1.00 * scale  # tfp
    B[0, 1] = 0.80 * scale  # government demand
    B[1, 1] = 0.40 * scale
    B[2, 0] = 0.70 * scale
    B[3, 1] = 1.20 * scale
    B[3, 3] = -0.80 * scale
    B[3, 4] = -0.80 * scale
    B[4, 2] = 1.00 * scale
    B[5, 5] = 0.60 * scale
    B[6, 2] = 1.00 * scale

    # Rule-of-thumb households strengthen fiscal demand effects.
    B[0, 1] *= (1.0 + 0.8 * lam)
    B[1, 1] *= (1.0 + 1.0 * lam)

    variable_index = {
        "y_hat": 0,
        "c_hat": 1,
        "i_hat": 2,
        "b_hat": 3,
        "pi_hat": 4,
        "l_hat": 5,
        "r_hat": 6,
    }
    shock_index = {
        "tfp": 0,
        "g": 1,
        "monetary": 2,
        "tau_l": 3,
        "tau_k": 4,
        "risk": 5,
    }

    C = np.eye(n)
    D = np.zeros((n, m))
    return A, B, C, D, variable_index, shock_index
