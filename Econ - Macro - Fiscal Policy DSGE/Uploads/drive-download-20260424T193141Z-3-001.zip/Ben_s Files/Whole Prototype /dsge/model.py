"""Assemble model objects used by the dashboard."""

from dsge.steady_state import compute_steady_state
from solvers.state_space import build_state_space


def solve_model_objects(params):
    steady_state = compute_steady_state(params)
    A, B, C, D, variable_index, shock_index = build_state_space(params)
    diagnostics = {
        "solver_success": True,
        "message": "State-space assembled successfully.",
    }
    return {
        "steady_state": steady_state,
        "A_matrix": A,
        "B_matrix": B,
        "C_matrix": C,
        "D_matrix": D,
        "variable_index": variable_index,
        "shock_index": shock_index,
        "diagnostics": diagnostics,
    }
