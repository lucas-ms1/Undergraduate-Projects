"""Impulse response calculations."""

import numpy as np

from policy.financing import financing_sign


def compute_irf(A, B, idx, sidx, shock_col, rule, horizon=40, shock_size=1.0):
    n = A.shape[0]
    x = np.zeros((horizon, n))
    eps0 = np.zeros(B.shape[1])
    eps0[sidx[shock_col]] = shock_size

    # Financing feedback changes debt channel intensity.
    debt_feedback_scale = 1.0 + 0.5 * financing_sign(rule)

    x[0] = B @ eps0
    for t in range(1, horizon):
        x[t] = A @ x[t - 1]
        x[t, idx["b_hat"]] *= debt_feedback_scale
    return x
