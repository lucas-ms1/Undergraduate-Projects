"""Fiscal multipliers and drag horizon."""

import numpy as np


def compute_multipliers(irf, idx, beta=0.99, g_ss=0.2, y_ss=1.0):
    y = irf[:, idx["y_hat"]] * y_ss
    g = irf[:, idx["b_hat"]] * g_ss
    impact = y[0] / g[0] if abs(g[0]) > 1e-9 else np.nan

    discount = beta ** np.arange(len(y))
    cum_num = np.sum(discount * y)
    cum_den = np.sum(discount * g)
    cumulative = cum_num / cum_den if abs(cum_den) > 1e-9 else np.nan

    drag = next((t for t in range(1, len(y)) if y[t] < 0), None)
    return {"impact_multiplier": impact, "cumulative_multiplier": cumulative, "fiscal_drag_horizon": drag}
