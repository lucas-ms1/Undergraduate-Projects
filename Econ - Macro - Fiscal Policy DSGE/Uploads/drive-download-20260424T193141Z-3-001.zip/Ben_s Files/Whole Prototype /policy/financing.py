"""Financing rule utilities."""


def financing_sign(rule):
    if rule in {"Consumption Tax Hikes", "Labor Tax Hikes", "Capital Tax Hikes"}:
        return 1.0
    # A rise in debt lowers transfers/spending in these rules.
    return -1.0
